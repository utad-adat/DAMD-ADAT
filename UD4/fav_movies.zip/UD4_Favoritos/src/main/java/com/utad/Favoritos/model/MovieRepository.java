package com.utad.Favoritos.model;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MovieRepository extends JpaRepository<Movie, Long> {

    // Se podría hacer así pero...
    // Spring Data JPA interpretará automáticamente el nombre del método y generará una consulta SQL adecuada que busque películas cuyo nombre contenga la cadena proporcionada, sin importar las diferencias de mayúsculas y minúsculas.
    // Esto se hace definiendo el nombre del método de acuerdo con las convenciones de nomenclatura de Spring Data.
    // @Query("SELECT m FROM Movie m WHERE LOWER(m.name) LIKE LOWER(CONCAT('%', :name, '%'))")
    List<Movie> findByNameContainingIgnoreCase(String name);

}
