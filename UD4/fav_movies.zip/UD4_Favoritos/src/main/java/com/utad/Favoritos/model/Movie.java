package com.utad.Favoritos.model;

import jakarta.persistence.*;
import lombok.Data;

import java.util.Date;

@Data
@Entity
@Table(name = "fav_movie")
public class Movie {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idMovie;

    @Column(nullable = false)
    private String name;

    private String genre;
    private Integer year;
    private Integer ranking;
}
