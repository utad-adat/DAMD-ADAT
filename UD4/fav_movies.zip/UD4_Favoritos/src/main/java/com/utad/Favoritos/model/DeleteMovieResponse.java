package com.utad.Favoritos.model;

import lombok.Data;

@Data //Lombok annotation para generar getters y setters
public class DeleteMovieResponse {

  private Long deletedMovieId;
  private String message;

}