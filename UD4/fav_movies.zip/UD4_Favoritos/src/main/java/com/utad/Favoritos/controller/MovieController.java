package com.utad.Favoritos.controller;

import com.utad.Favoritos.model.DeleteMovieResponse;
import com.utad.Favoritos.model.Movie;
import com.utad.Favoritos.service.MovieService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping(path = "api/v1/movies")
public class MovieController {

    private final MovieService movieService;

    @Autowired
    public MovieController(MovieService movieService) {
        this.movieService = movieService;
    }

    @GetMapping
    public ResponseEntity<List<Movie>> getAll() {
        List<Movie> movies = movieService.getMovies();
        return ResponseEntity.ok(movies);
    }

    @PostMapping
    public ResponseEntity<Movie> save(@RequestBody Movie movie) {
        Movie created = movieService.saveOrUpdate(movie);
        return ResponseEntity.status(HttpStatus.ACCEPTED).body(created);
    }

    @DeleteMapping("/{idMovie}")
    public ResponseEntity<Object> delete(@PathVariable("idMovie") Long idMovie) {
        this.movieService.deleteMovie(idMovie);
        DeleteMovieResponse response = new DeleteMovieResponse();
        response.setMessage("Movie with id " + idMovie + " was deleted");
        response.setDeletedMovieId(idMovie);

        return ResponseEntity.ok(response);
    }

    @GetMapping("/{idMovie}")
    public ResponseEntity<Optional<Movie>> getById(@PathVariable Long idMovie) {
        Optional<Movie> movie = movieService.getMovie(idMovie);

        if (movie.isPresent()) {
            return ResponseEntity.ok(movie);
        }

        return ResponseEntity.notFound().build();
    }

    @GetMapping("/search")
    public ResponseEntity<List<Movie>> searchMovies(@RequestParam String name) {
        List<Movie> movies = movieService.searchByName(name);
        return ResponseEntity.ok(movies);
    }

}
