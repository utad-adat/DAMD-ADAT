package com.utad.Favoritos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FavoritosApplicationTests {

	@Test
	void contextLoads() {
	}

}
