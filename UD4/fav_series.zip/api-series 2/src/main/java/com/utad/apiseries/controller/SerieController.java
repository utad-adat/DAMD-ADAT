package com.utad.apiseries.controller;
import com.utad.apiseries.model.Serie;
import com.utad.apiseries.service.SerieService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping(path = "api/v1/series")
public class SerieController {
    private final SerieService serieService;
    @Autowired
    public SerieController(SerieService serieService) {
        this.serieService = serieService;
    }

    @PostMapping
    public ResponseEntity<Serie> save(@RequestBody Serie serie) {
        Serie serieNew = serieService.saveOrUpdate(serie);
        return ResponseEntity.status(HttpStatus.ACCEPTED).body(serieNew);
    }

    @GetMapping
    public ResponseEntity<List<Serie>> getAll() {
        List<Serie> series = serieService.getSeries();
        return ResponseEntity.ok(series);
    }

    @GetMapping("/{idSerie}")
    public ResponseEntity<Optional<Serie>> getById(@PathVariable Long idSerie) {
        Optional<Serie> serie = serieService.getSerie(idSerie);
        if (serie.isPresent())
            return ResponseEntity.ok(serie);
        return ResponseEntity.notFound().build();
    }

    @GetMapping("/search")
    public ResponseEntity<List<Serie>> searchMovies(@RequestParam String name) {
        List<Serie> series = serieService.searchByName(name);
        return ResponseEntity.ok(series);
    }

    @DeleteMapping("/{idSerie}")
    public ResponseEntity<Optional<Serie>> delete(@PathVariable Long idSerie) {
        serieService.deleteSerie(idSerie);
        return ResponseEntity.ok().build();
    }
}
