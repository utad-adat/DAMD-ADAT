package com.utad.apiseries;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiSeriesApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiSeriesApplication.class, args);
	}

}
