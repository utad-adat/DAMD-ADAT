package com.utad.apiseries;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiSeriesApplicationTests {

	@Test
	void contextLoads() {
	}

}
